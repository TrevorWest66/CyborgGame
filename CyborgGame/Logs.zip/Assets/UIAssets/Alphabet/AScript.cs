﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AScript : MonoBehaviour
{
	// Start is called before the first frame update
	[SerializeField] private Text nameField;

	public void setLetterA()
	{
		nameField.text += "A";
	}

	public void setLetterB()
	{
		nameField.text += "B";
	}

	public void setLetterC()
	{
		nameField.text += "C";
	}

	public void setLetterD()
	{
		nameField.text += "D";
	}

	public void setLetterE()
	{
		nameField.text += "E";
	}

	public void setLetterF()
	{
		nameField.text += "F";
	}

	public void setLetterG()
	{
		nameField.text += "G";
	}

	public void setLetterH()
	{
		nameField.text += "H";
	}

	public void setLetterI()
	{
		nameField.text += "I";
	}

	public void setLetterJ()
	{
		nameField.text += "J";
	}

	public void setLetterK()
	{
		nameField.text += "K";
	}

	public void setLetterL()
	{
		nameField.text += "L";
	}

	public void setLetterM()
	{
		nameField.text += "M";
	}

	public void setLetterN()
	{
		nameField.text += "N";
	}

	public void setLetterO()
	{
		nameField.text += "O";
	}

	public void setLetterP()
	{
		nameField.text += "P";
	}

	public void setLetterQ()
	{
		nameField.text += "Q";
	}

	public void setLetterR()
	{
		nameField.text += "R";
	}

	public void setLetterS()
	{
		nameField.text += "S";
	}

	public void setLetterT()
	{
		nameField.text += "T";
	}

	public void setLetterU()
	{
		nameField.text += "U";
	}

	public void setLetterV()
	{
		nameField.text += "V";
	}

	public void setLetterW()
	{
		nameField.text += "W";
	}

	public void setLetterX()
	{
		nameField.text += "X";
	}

	public void setLetterY()
	{
		nameField.text += "Y";
	}

	public void setLetterZ()
	{
		nameField.text += "Z";
	}
}
